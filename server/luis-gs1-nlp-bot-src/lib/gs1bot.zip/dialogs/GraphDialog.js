"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const cancelAndHelpDialog_1 = require("./cancelAndHelpDialog");
const GRAPH_WATERFALL = 'graphWaterFall';
class GraphDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'graphDialog');
        this.waterFallDialog = new botbuilder_dialogs_1.WaterfallDialog(GRAPH_WATERFALL, [
            this.loopStep.bind(this)
        ]);
        this.addDialog(this.waterFallDialog);
        this.initialDialogId = GRAPH_WATERFALL;
    }
    initGraph(graph) {
        this.initialGraph = graph;
        this.dialogGraph = graph;
    }
    reloadStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            this.dialogGraph = this.dialogGraph.next(stepContext.result);
            console.log('reload-step');
            this.waterFallDialog.addStep(this.loopStep.bind(this));
            return yield stepContext.continueDialog();
        });
    }
    loopStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.dialogGraph) {
                this.waterFallDialog
                    .addStep(this.dialogGraph.step.bind(this))
                    .addStep(this.reloadStep.bind(this));
            }
            else {
                this.dialogGraph = this.initialGraph;
                this.waterFallDialog.addStep(this.loopStep.bind(this));
                return yield stepContext.endDialog();
            }
            return yield stepContext.continueDialog();
        });
    }
}
exports.GraphDialog = GraphDialog;
// tslint:disable-next-line: max-classes-per-file
class DialogGraphNode {
    // TODO in future: remove textpromptstring as dependency from dialoggraph
    constructor(step, nodeLabel = 'node', defaultNext = null) {
        this.step = step;
        this.nodeLabel = nodeLabel;
        this.defaultNext = defaultNext;
    }
    setDefault(dialogGraph) {
        this.defaultNext = dialogGraph;
        return this;
    }
}
exports.DialogGraphNode = DialogGraphNode;
// tslint:disable-next-line: max-classes-per-file
class ConditionalDialogGraphNode extends DialogGraphNode {
    // constructor(public step: WaterfallStep, defaultNext: DialogGraphNode = null){
    //     super(step,defaultNext);
    // }
    setTrueDialog(dialogNode) {
        this.trueDialogNode = dialogNode;
        return this;
    }
    setFalseDialog(dialogNode) {
        this.falseDialogNode = dialogNode;
        return this;
    }
    setCondition(condition) {
        this.condition = condition;
        return this;
    }
    next(condition) {
        if (condition) {
            // console.log(`conditionalNode: true : ${this.nodeLabel}`)
            return condition() ? this.trueDialogNode : this.falseDialogNode;
        }
        else {
            // console.log(`conditionalNode: false : ${this.nodeLabel}`)
            return this.condition() ? this.trueDialogNode : this.falseDialogNode;
        }
    }
}
exports.ConditionalDialogGraphNode = ConditionalDialogGraphNode;
// tslint:disable-next-line: max-classes-per-file
class AnswerDialogGraphNode extends DialogGraphNode {
    constructor(step, nodeLabel = 'node', dialogDictionary = {}, defaultNext = null) {
        super(step, nodeLabel, defaultNext);
        this.step = step;
        this.nodeLabel = nodeLabel;
        this.dialogDictionary = dialogDictionary;
    }
    addNext(input, dialogGraph) {
        if (input) {
            this.dialogDictionary[input] = dialogGraph;
        }
        return this;
    }
    next(input) {
        const output = this.dialogDictionary[input];
        // console.log(`Next graphnode:${output ? output.nodeLabel : this.defaultNext && this.defaultNext.nodeLabel} --- coming from: ${this.nodeLabel}`);
        return output ? output : this.defaultNext;
    }
}
exports.AnswerDialogGraphNode = AnswerDialogGraphNode;
// // tslint:disable-next-line: max-classes-per-file
// export class ConditionalDialogGraph extends DialogGraph {
//     private trueDialog:DialogGraph;
//     private falseDialog: DialogGraph;
//     public addFalseDialog(dialogGraph: DialogGraph): this {
//         this.falseDialog = dialogGraph;
//         return this;
//     }
//     public addTrueDialog(dialogGraph: DialogGraph): this {
//         this.trueDialog = dialogGraph;
//         return this;
//     }
//     public nextDialog(bool: boolean){
//         return bool? this.trueDialog: this.falseDialog;
//     }
// }
//# sourceMappingURL=GraphDialog.js.map