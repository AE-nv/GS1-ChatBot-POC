"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const botbuilder_ai_1 = require("botbuilder-ai");
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const QNAMakerClient_1 = __importDefault(require("../integrations/qnamaker/QNAMakerClient"));
const cancelAndHelpDialog_1 = require("./cancelAndHelpDialog");
const CONFIRM_PROMPT = 'confirmPrompt';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';
class QNADialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id, qnaLuisRecognizer) {
        super(id || 'qnaDialog');
        this.qnaLuisRecognizer = qnaLuisRecognizer;
        this.addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT))
            .addDialog(new botbuilder_dialogs_1.ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new botbuilder_dialogs_1.WaterfallDialog(WATERFALL_DIALOG, [
            this.analyzeInputStep.bind(this),
        ]));
        this.initialDialogId = WATERFALL_DIALOG;
        this.qnaMakerClient = new QNAMakerClient_1.default('36677783-1246-4ab8-8ec5-197f0f829f5b', 'cbde9f34-58cf-46d5-af76-975d99df84eb', 'https://gs1-pocbot.azurewebsites.net');
    }
    analyzeInputStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const luisResult = yield this.qnaLuisRecognizer.executeLuisQuery(stepContext.context);
            console.log(stepContext.context._activity.text);
            console.log(botbuilder_ai_1.LuisRecognizer.topIntent(luisResult));
            const qnaResponse = yield this.qnaMakerClient.getAnswerForQuestion(stepContext.context._activity.text);
            return yield stepContext.prompt(TEXT_PROMPT, { prompt: `Ik denk dat je vraag binnen categorie: ${botbuilder_ai_1.LuisRecognizer.topIntent(luisResult)} ligt met als antwoord: ${qnaResponse.answers[0].answer}` });
        });
    }
}
exports.QNADialog = QNADialog;
//# sourceMappingURL=qnaDialog.js.map