"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const botbuilder_1 = require("botbuilder");
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const QNAMakerClient_1 = __importDefault(require("../integrations/qnamaker/QNAMakerClient"));
const cancelAndHelpDialog_1 = require("./cancelAndHelpDialog");
const strings_1 = __importDefault(require("./strings"));
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';
const CONFIRM_PROMPT = 'confirmPrompt';
class QNADialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'qnaDialog');
        this.addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT))
            .addDialog(new botbuilder_dialogs_1.WaterfallDialog(WATERFALL_DIALOG, [
            this.poseQuestionStep.bind(this),
            this.analyzeInputStep.bind(this),
            this.wasThisUsefulStep.bind(this),
        ]));
        this.initialDialogId = WATERFALL_DIALOG;
        this.qnaMakerClient = new QNAMakerClient_1.default('36677783-1246-4ab8-8ec5-197f0f829f5b', 'cbde9f34-58cf-46d5-af76-975d99df84eb', 'https://gs1-pocbot.azurewebsites.net');
    }
    poseQuestionStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield stepContext.prompt(TEXT_PROMPT, { prompt: strings_1.default.faq.pose_question });
        });
    }
    analyzeInputStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            // const luisResult = await this.qnaLuisRecognizer.executeLuisQuery(stepContext.context);
            // console.log(LuisRecognizer.topIntent(luisResult))
            const qnaResponse = yield this.qnaMakerClient.getAnswerForQuestion(stepContext.context.activity.text);
            yield stepContext.context.sendActivity(qnaResponse.answers[0].answer);
            const introActions = botbuilder_1.CardFactory.actions([strings_1.default.general.yes, strings_1.default.general.no]);
            return yield stepContext.prompt(TEXT_PROMPT, botbuilder_1.MessageFactory
                .suggestedActions(introActions, strings_1.default.faq.was_this_useful));
        });
    }
    wasThisUsefulStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            if (stepContext.result.toLowerCase() === strings_1.default.general.yes.toLowerCase()) {
                yield stepContext.prompt(TEXT_PROMPT, { prompt: strings_1.default.faq.thanks_for_feedback });
                return yield stepContext.endDialog();
            }
            else {
                yield stepContext.context.sendActivity(strings_1.default.faq.pose_differently);
                // await stepContext.endDialog();
                return yield stepContext.replaceDialog(this.id, { accessor: this.accessor });
            }
        });
    }
}
exports.QNADialog = QNADialog;
//# sourceMappingURL=qnaDialog.js.map