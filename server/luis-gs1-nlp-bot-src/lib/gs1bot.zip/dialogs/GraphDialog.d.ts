import { WaterfallStep, WaterfallStepContext } from 'botbuilder-dialogs';
import { CancelAndHelpDialog } from './cancelAndHelpDialog';
export declare class GraphDialog extends CancelAndHelpDialog {
    private waterFallDialog;
    private dialogGraph;
    private initialGraph;
    constructor(id: any);
    initGraph(graph: DialogGraphNode): void;
    reloadStep(stepContext: WaterfallStepContext): Promise<import("botbuilder-dialogs").DialogTurnResult<any>>;
    loopStep(stepContext: WaterfallStepContext): Promise<import("botbuilder-dialogs").DialogTurnResult<any>>;
}
export declare abstract class DialogGraphNode {
    step: WaterfallStep;
    nodeLabel: string;
    protected defaultNext: DialogGraphNode;
    constructor(step: WaterfallStep, nodeLabel?: string, defaultNext?: DialogGraphNode);
    abstract next(input?: any): DialogGraphNode;
    setDefault(dialogGraph: DialogGraphNode): this;
}
export declare class ConditionalDialogGraphNode extends DialogGraphNode {
    trueDialogNode: DialogGraphNode;
    falseDialogNode: DialogGraphNode;
    private condition;
    setTrueDialog(dialogNode: DialogGraphNode): this;
    setFalseDialog(dialogNode: DialogGraphNode): this;
    setCondition(condition: () => boolean): this;
    next(condition?: () => boolean): DialogGraphNode;
}
export declare class AnswerDialogGraphNode extends DialogGraphNode {
    step: WaterfallStep;
    nodeLabel: string;
    private dialogDictionary;
    constructor(step: WaterfallStep, nodeLabel?: string, dialogDictionary?: {
        [answers: string]: DialogGraphNode;
    }, defaultNext?: DialogGraphNode);
    addNext(input: string, dialogGraph: DialogGraphNode): this;
    next(input?: string): DialogGraphNode;
}
