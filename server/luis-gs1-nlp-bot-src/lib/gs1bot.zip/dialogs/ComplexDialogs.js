"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const strings_1 = __importDefault(require("./strings"));
class ComplexDialog {
    constructor(dialogText, options = {}) {
        this.dialogText = dialogText;
        this.options = options;
        this.DEFAULT_NEXT_KEY = 'irezerd-g-fg-h--gh-h-fgfffhàç(ç(((d';
    }
    getNext(answer) {
        return this.options[answer] ? this.options[answer] : (this.options[this.DEFAULT_NEXT_KEY] ? this.options[this.DEFAULT_NEXT_KEY] : null);
    }
    get getPossibleAnswers() {
        const strippedObj = this.options;
        delete strippedObj[this.DEFAULT_NEXT_KEY];
        return Object.keys(strippedObj);
    }
    addOption(answer, dialog) {
        const key = answer ? answer : this.DEFAULT_NEXT_KEY;
        this.options[key] = dialog;
        return this;
    }
}
exports.ComplexDialog = ComplexDialog;
exports.prefixChoiceDialog = new ComplexDialog(strings_1.default.gtin.for_cd_or_other)
    .addOption(strings_1.default.gtin.possible_answers.other, new ComplexDialog(strings_1.default.gtin.need_prefix)
    .addOption(undefined, new ComplexDialog(strings_1.default.gtin.is_revenue_correct('5 miljard'))
    .addOption(strings_1.default.general.yes, new ComplexDialog('test'))));
//# sourceMappingURL=ComplexDialogs.js.map