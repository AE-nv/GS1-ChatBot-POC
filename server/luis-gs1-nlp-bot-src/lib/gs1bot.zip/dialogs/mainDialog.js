"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const botbuilder_1 = require("botbuilder");
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const strings_1 = __importDefault(require("./strings"));
const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
const TEXT_PROMPT = 'TextPrompt';
const QNA_DIALOG = 'qnaDialog';
class MainDialog extends botbuilder_dialogs_1.ComponentDialog {
    constructor(mainLuisRecognizer, qnaLuisRecognizer, qnaDialog) {
        super('MainDialog');
        this.mainLuisRecognizer = mainLuisRecognizer;
        this.qnaLuisRecognizer = qnaLuisRecognizer;
        this.qnaDialog = qnaDialog;
        if (!mainLuisRecognizer)
            throw new Error('[MainDialog]: Missing parameter \'luisRecognizer\' is required');
        if (!qnaDialog)
            throw new Error('[MainDialog]: Missing parameter \'bookingDialog\' is required');
        // Define the main dialog and its related components.
        // This is a sample "book a flight" dialog.
        this.addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT))
            .addDialog(qnaDialog)
            .addDialog(new botbuilder_dialogs_1.WaterfallDialog(MAIN_WATERFALL_DIALOG, [
            this.introStep.bind(this),
            this.chooseBarcodeOrFAQStep.bind(this),
            this.finalStep.bind(this)
        ]));
        this.initialDialogId = MAIN_WATERFALL_DIALOG;
    }
    /**
     * The run method handles the incoming activity (in the form of a TurnContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {*} turnContext
     * @param {*} accessor
     */
    run(turnContext, accessor) {
        return __awaiter(this, void 0, void 0, function* () {
            const dialogSet = new botbuilder_dialogs_1.DialogSet(accessor);
            dialogSet.add(this);
            const dialogContext = yield dialogSet.createContext(turnContext);
            const results = yield dialogContext.continueDialog();
            if (results.status === botbuilder_dialogs_1.DialogTurnStatus.empty) {
                yield dialogContext.beginDialog(this.id);
            }
        });
    }
    introStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            let messageText = '';
            if (!this.mainLuisRecognizer.isConfigured) {
                messageText = 'NOTE: LUIS is not configured. To enable all capabilities, add `LuisAppId`, `LuisAPIKey` and `LuisAPIHostName` to the .env file.';
                yield stepContext.context.sendActivity(messageText, null, botbuilder_1.InputHints.IgnoringInput);
                return yield stepContext.next();
            }
            messageText = stepContext.options.restartMsg ? stepContext.options.restartMsg : `${strings_1.default.main.welcome.introduction}`;
            const introActions = botbuilder_1.CardFactory.actions([strings_1.default.main.welcome.possibilities.create_barcode, strings_1.default.main.welcome.possibilities.ask_question]);
            return yield stepContext.prompt(TEXT_PROMPT, botbuilder_1.MessageFactory
                .suggestedActions(introActions, messageText));
        });
    }
    chooseBarcodeOrFAQStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const answerOfUser = stepContext.context.activity.text;
            switch (answerOfUser) {
                case strings_1.default.main.welcome.possibilities.ask_question: return yield stepContext.beginDialog(QNA_DIALOG);
                case strings_1.default.main.welcome.possibilities.create_barcode:
                    yield stepContext.context.sendActivity('todo', 'todo', botbuilder_1.InputHints.IgnoringInput);
                    return yield stepContext.next();
            }
            // Call LUIS and gather any potential booking details. (Note the TurnContext has the response to the prompt)
            // const luisResult = await this.mainLuisRecognizer.executeLuisQuery(stepContext.context);
            // switch (LuisRecognizer.topIntent(luisResult)) {
            // case 'CreateBarCode':
            //     // Run the BookingDialog passing in whatever details we have from the LUIS call, it will fill out the remainder.
            //     return await stepContext.context.sendActivity('todo', 'todo', InputHints.IgnoringInput);
            //     // return await stepContext.beginDialog('bookingDialog', bookingDetails);
            // case 'AskQuestion':
            //     return await stepContext.beginDialog('qnaDialog');
            // case 'GetWeather':
            //     // We haven't implemented the GetWeatherDialog so we just display a TODO message.
            //     const getWeatherMessageText = 'TODO: get weather flow here';
            //     await stepContext.context.sendActivity(getWeatherMessageText, getWeatherMessageText, InputHints.IgnoringInput);
            //     break;
            // default:
            //     // Catch all for unhandled intents
            //     const didntUnderstandMessageText = `Sorry, I didn't get that. Please try asking in a different way (intent was ${ LuisRecognizer.topIntent(luisResult) })`;
            //     await stepContext.context.sendActivity(didntUnderstandMessageText, didntUnderstandMessageText, InputHints.IgnoringInput);
            // }
            return yield stepContext.next();
        });
    }
    /**
     * This is the final step in the main waterfall dialog.
     * It wraps up the sample "book a flight" interaction with a simple confirmation.
     */
    finalStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            // If the child dialog ("bookingDialog") was cancelled or the user failed to confirm, the Result here will be null.
            // Restart the main dialog with a different message the second time around
            return yield stepContext.replaceDialog(this.initialDialogId, { restartMsg: strings_1.default.main.what_else });
        });
    }
}
exports.MainDialog = MainDialog;
//# sourceMappingURL=mainDialog.js.map