"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
const botbuilder_1 = require("botbuilder");
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const ConsoleBotTelemetryClient_1 = require("../util/ConsoleBotTelemetryClient");
const PromptFactory_1 = require("../util/PromptFactory");
const needGtinDialog_1 = require("./gtinDialogs/needGtinDialog");
const qnaDialog_1 = require("./qnaDialog");
const strings_1 = __importDefault(require("./strings"));
const MAIN_WATERFALL_DIALOG = 'mainWaterfallDialog';
const TEXT_PROMPT = 'TextPrompt';
const QNA_DIALOG = 'qnaDialog';
const NEED_GTIN_DIALOG = 'needGtinDialog';
class MainDialog extends botbuilder_dialogs_1.ComponentDialog {
    constructor() {
        super('MainDialog');
        this.accessor = null;
        // Define the main dialog and its related components.
        // This is a sample "book a flight" dialog.
        this.addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT))
            .addDialog(new qnaDialog_1.QNADialog(QNA_DIALOG))
            .addDialog(new needGtinDialog_1.NeedGtinDialog(NEED_GTIN_DIALOG))
            .addDialog(new botbuilder_dialogs_1.WaterfallDialog(MAIN_WATERFALL_DIALOG, [
            this.introStep.bind(this),
            this.newUserStep.bind(this),
            this.setUserDetailsStep.bind(this),
            this.poseHelpPossibilities.bind(this),
            this.possibilityPickedStep.bind(this),
            this.finalStep.bind(this)
        ]));
        this.initialDialogId = MAIN_WATERFALL_DIALOG;
    }
    /**
     * The run method handles the incoming activity (in the form of a TurnContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {*} turnContext
     * @param {*} accessor
     */
    run(turnContext, accessor) {
        return __awaiter(this, void 0, void 0, function* () {
            const dialogSet = new botbuilder_dialogs_1.DialogSet(accessor);
            dialogSet.add(this);
            this.accessor = accessor;
            const dialogContext = yield dialogSet.createContext(turnContext);
            dialogContext.dialogs.telemetryClient = new ConsoleBotTelemetryClient_1.ConsoleLogTelemetryClient();
            const results = yield dialogContext.continueDialog();
            if (results.status === botbuilder_dialogs_1.DialogTurnStatus.empty) {
                yield dialogContext.beginDialog(this.id);
            }
        });
    }
    introStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            let messageText = '';
            messageText = stepContext.options.isRestart ? stepContext.options.restartMsg : `${strings_1.default.main.welcome.introduction}`;
            if (!stepContext.options.isRestart) {
                yield stepContext.context.sendActivity(messageText);
            }
            return yield stepContext.next();
        });
    }
    newUserStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.accessor.get(stepContext.context);
            if (userDetails.newUser !== undefined) {
                return yield stepContext.next();
            }
            const introActions = botbuilder_1.CardFactory.actions([strings_1.default.general.yes, strings_1.default.general.no]);
            return yield stepContext.prompt(TEXT_PROMPT, botbuilder_1.MessageFactory
                .suggestedActions(introActions, strings_1.default.main.new_user));
        });
    }
    setUserDetailsStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const answerOfUser = stepContext.result;
            const userDetails = yield this.accessor.get(stepContext.context);
            if (answerOfUser === strings_1.default.general.yes) {
                userDetails.newUser = true;
            }
            else {
                userDetails.newUser = false;
            }
            return yield stepContext.next();
        });
    }
    poseHelpPossibilities(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const introActions = botbuilder_1.CardFactory.actions([
                strings_1.default.main.help.possibilities.need_lei,
                strings_1.default.main.help.possibilities.need_gtin,
                strings_1.default.main.help.possibilities.general_question
            ]);
            return yield stepContext.prompt(TEXT_PROMPT, botbuilder_1.MessageFactory
                .suggestedActions(introActions, strings_1.default.main.help.what_can_i_do));
        });
    }
    possibilityPickedStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const answerOfUser = stepContext.result;
            switch (answerOfUser) {
                case strings_1.default.main.help.possibilities.general_question:
                    return yield stepContext.beginDialog(QNA_DIALOG, { accessor: this.accessor });
                case strings_1.default.main.help.possibilities.need_gtin:
                    return yield stepContext.beginDialog(NEED_GTIN_DIALOG, { accessor: this.accessor });
                case strings_1.default.main.help.possibilities.need_lei:
                    yield PromptFactory_1.getTextPrompt(stepContext, TEXT_PROMPT, strings_1.default.main.lei);
                    return yield stepContext.next();
                default:
                    yield stepContext.context.sendActivity('todo', 'todo', botbuilder_1.InputHints.IgnoringInput);
                    return yield stepContext.next();
            }
        });
    }
    finalStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield stepContext.replaceDialog(this.initialDialogId, { isRestart: true, restartMsg: strings_1.default.main.what_else });
        });
    }
}
exports.MainDialog = MainDialog;
//# sourceMappingURL=mainDialog.js.map