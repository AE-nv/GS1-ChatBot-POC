"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const WATERFALL_DIALOG = 'prefixChoiceWaterfal';
const TEXT_PROMPT = 'textPrompt';
class PrefixChoiceFlow extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'prefixChoiceFlow');
        this.addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT));
    }
}
exports.PrefixChoiceFlow = PrefixChoiceFlow;
//# sourceMappingURL=prefixChoiceFlow.js.map