"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const PromptFactory_1 = require("../../util/PromptFactory");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const retrieveRevenueDialog_1 = require("./retrieveRevenueDialog");
const TEXT_PROMPT = 'gtinForCD';
const RETRIEVE_REVENUE_DIALOG = 'gtinForCSRetrieveRevenue';
class GtinForCDDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'gtinForCDDialog');
        this.addDialog(new botbuilder_dialogs_1.WaterfallDialog('gtinForCDWaterfall', [
            this.specialOfferStep.bind(this),
            this.pickNextDialogStep.bind(this)
        ]))
            .addDialog(new retrieveRevenueDialog_1.RetrieveRevenueDialog(RETRIEVE_REVENUE_DIALOG))
            .addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT));
        this.initialDialogId = 'gtinForCDWaterfall';
    }
    specialOfferStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield PromptFactory_1.getChoicePrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.special_offer, [strings_1.default.general.no, strings_1.default.general.yes]);
        });
    }
    pickNextDialogStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            switch (stepContext.result) {
                case strings_1.default.general.no:
                    yield PromptFactory_1.getTextPrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.no_problem);
                    return yield stepContext.beginDialog(RETRIEVE_REVENUE_DIALOG, { accessor: this.accessor });
                case strings_1.default.general.yes:
                    yield PromptFactory_1.getTextPrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.cd_dvd_vinyl_form);
            }
            return yield stepContext.endDialog({ meta: 'userChoseSpecialOffer' });
        });
    }
}
exports.GtinForCDDialog = GtinForCDDialog;
//# sourceMappingURL=gtinForCDDialog.js.map