import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class GtinForCDDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private specialOfferStep;
    private pickNextDialogStep;
}
