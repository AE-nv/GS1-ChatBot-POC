import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class GtinForOtherDialog extends CancelAndHelpDialog {
    constructor(id: any);
}
