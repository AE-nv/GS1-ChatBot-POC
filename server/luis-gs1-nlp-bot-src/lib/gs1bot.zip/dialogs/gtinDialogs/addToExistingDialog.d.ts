import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class AddToExistingPrefixDialog extends CancelAndHelpDialog {
    constructor(id: string);
    private askIfUserWantsToAddToExistingPrefixStep;
    private processResultStep;
    private returnResultStep;
}
