import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class PrefixChoiceFlow extends CancelAndHelpDialog {
    constructor(id: any);
}
