"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const PromptFactory_1 = require("../../util/PromptFactory");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const enterRevenueDialog_1 = require("./enterRevenueDialog");
const isCorrectRevenueDialog_1 = require("./isCorrectRevenueDialog");
const CORRECT_REVENUE_DIALOG = 'needPrefixIsCorrectRevenueDialog';
const FILL_IN_REVENUE_DIALOG = 'needPrefixFillInRevenueDialog';
const RETRIEVE_REVENUE_WATERFALL = 'retrieveRevenueWaterfall';
const TEXT_PROMPT = 'retrieveRevTextPrompt';
class RetrieveRevenueDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'needPrefixDialog');
        this.addDialog(new botbuilder_dialogs_1.WaterfallDialog(RETRIEVE_REVENUE_WATERFALL, [
            this.introStep.bind(this),
            this.readyStep.bind(this),
            this.checkRevenueStep.bind(this),
            this.processResultStep.bind(this),
        ]))
            .addDialog(new isCorrectRevenueDialog_1.IsCorrectRevenueDialog(CORRECT_REVENUE_DIALOG))
            .addDialog(new enterRevenueDialog_1.EnterRevenueDialog(FILL_IN_REVENUE_DIALOG))
            .addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT));
        this.initialDialogId = RETRIEVE_REVENUE_WATERFALL;
    }
    introStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const isFirstTimeEnter = stepContext.options && stepContext.options.firstTimeEnter;
            if (isFirstTimeEnter) {
                yield PromptFactory_1.getTextPrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.ask_some_questions);
            }
            return yield stepContext.next();
        });
    }
    readyStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const isFirstTimeEnter = stepContext.options && stepContext.options.firstTimeEnter;
            if (isFirstTimeEnter) {
                yield PromptFactory_1.getTextPrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.ready_here_we_go);
            }
            return yield stepContext.next();
        });
    }
    checkRevenueStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            if (!!userDetails.revenue) {
                return yield stepContext.beginDialog(CORRECT_REVENUE_DIALOG, { accessor: this.accessor });
            }
            else {
                return yield stepContext.beginDialog(FILL_IN_REVENUE_DIALOG, { accessor: this.accessor });
            }
        });
    }
    processResultStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(stepContext.result);
            if (stepContext.result === strings_1.default.general.yes) {
                return yield stepContext.endDialog(); // if yes is the result, it means that the source dialog (from where the result came from) is the 'CorrectRevenueDialog' and thus, the dialog can be ended.
            }
            else {
                return yield stepContext.replaceDialog(RETRIEVE_REVENUE_WATERFALL, { accessor: this.accessor });
            }
        });
    }
}
exports.RetrieveRevenueDialog = RetrieveRevenueDialog;
//# sourceMappingURL=retrieveRevenueDialog.js.map