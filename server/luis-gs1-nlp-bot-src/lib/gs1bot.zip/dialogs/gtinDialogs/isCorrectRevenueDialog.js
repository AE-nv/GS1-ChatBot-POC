"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const PromptFactory_1 = require("../../util/PromptFactory");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const ENTER_REVENUE_DIALOG = 'correctRevEnterRevDialog';
const TEXT_PROMPT = 'isCorrectRevenueTextPrompt';
class IsCorrectRevenueDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'iscorrectrevDialog');
        this.addDialog(new botbuilder_dialogs_1.WaterfallDialog('isCorrectRevWaterfall', [
            this.isCorrectRevStep.bind(this),
            // this.nextDialogStep.bind(this),
            this.resetIfNotCorrectAndEndStep.bind(this),
        ]))
            // .addDialog(new EnterRevenueDialog(ENTER_REVENUE_DIALOG))
            .addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT));
        this.initialDialogId = 'isCorrectRevWaterfall';
    }
    isCorrectRevStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            return yield PromptFactory_1.getChoicePrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.is_revenue_correct(userDetails.revenue), [strings_1.default.general.yes, strings_1.default.general.no]);
        });
    }
    // private async nextDialogStep(stepContext:WaterfallStepContext){
    //     switch(stepContext.result){
    //         case strings.general.yes:
    //             stepContext.next(); // proceed to final step where the normal flow is continued.
    //         case strings.general.no:
    //             return await stepContext.beginDialog(ENTER_REVENUE_DIALOG, this.accessor);
    //     }
    // }
    resetIfNotCorrectAndEndStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            console.log(`ResetAfterNotCorrectRevStep: ${stepContext.result}`);
            if (stepContext.result === strings_1.default.general.no) {
                userDetails.revenue = undefined;
            }
            return yield stepContext.endDialog(stepContext.result);
        });
    }
}
exports.IsCorrectRevenueDialog = IsCorrectRevenueDialog;
//# sourceMappingURL=isCorrectRevenueDialog.js.map