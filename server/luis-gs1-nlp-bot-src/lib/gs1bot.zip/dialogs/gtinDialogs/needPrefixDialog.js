"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const enterRevenueDialog_1 = require("./enterRevenueDialog");
const isCorrectRevenueDialog_1 = require("./isCorrectRevenueDialog");
const CORRECT_REVENUE_DIALOG = 'needPrefixIsCorrectRevenueDialog';
const FILL_IN_REVENUE_DIALOG = 'needPrefixFillInRevenueDialog';
class NeedPrefixDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'needPrefixDialog');
        this.addDialog(new botbuilder_dialogs_1.WaterfallDialog('needPrefixWaterfall', [
            this.checkRevenueStep.bind(this),
            this.finalStep.bind(this)
        ]))
            .addDialog(new isCorrectRevenueDialog_1.IsCorrectRevenueDialog(CORRECT_REVENUE_DIALOG))
            .addDialog(new enterRevenueDialog_1.EnterRevenueDialog(FILL_IN_REVENUE_DIALOG));
        this.initialDialogId = 'needPrefixWaterfall';
    }
    checkRevenueStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!!this.userDetails.revenue) {
                return yield stepContext.beginDialog(CORRECT_REVENUE_DIALOG, this.accessor);
            }
            else {
                return yield stepContext.beginDialog(FILL_IN_REVENUE_DIALOG, this.accessor);
            }
        });
    }
    finalStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            stepContext.endDialog();
        });
    }
}
exports.NeedPrefixDialog = NeedPrefixDialog;
//# sourceMappingURL=needPrefixDialog.js.map