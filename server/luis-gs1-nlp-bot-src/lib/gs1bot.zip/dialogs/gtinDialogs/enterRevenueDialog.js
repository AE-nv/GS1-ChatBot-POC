"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const PromptFactory_1 = require("../../util/PromptFactory");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const IS_CORRECT_REVENUE_DIALOG = 'enterRevIsCorrectRevDIALOG';
const TEXT_PROMPT = 'enterRevTextprompt';
class EnterRevenueDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'enterRevDialog');
        this.addDialog(new botbuilder_dialogs_1.WaterfallDialog('enterRevWaterfallDialog', [
            this.giveRevenueStep.bind(this),
            this.finalStep.bind(this)
        ]))
            .addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT));
        this.initialDialogId = 'enterRevWaterfallDialog';
    }
    giveRevenueStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield PromptFactory_1.getTextPrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.give_revenue_please);
        });
    }
    finalStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            console.log(stepContext.result);
            userDetails.revenue = stepContext.result;
            return yield stepContext.endDialog();
        });
    }
}
exports.EnterRevenueDialog = EnterRevenueDialog;
//# sourceMappingURL=enterRevenueDialog.js.map