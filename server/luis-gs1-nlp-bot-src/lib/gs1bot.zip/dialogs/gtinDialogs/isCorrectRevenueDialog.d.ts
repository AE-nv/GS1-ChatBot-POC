import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class IsCorrectRevenueDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private isCorrectRevStep;
    private resetIfNotCorrectAndEndStep;
}
