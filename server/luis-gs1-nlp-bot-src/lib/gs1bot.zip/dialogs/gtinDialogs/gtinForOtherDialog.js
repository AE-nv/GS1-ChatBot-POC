"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
class GtinForOtherDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'gtinForOtherDialog');
        // this.addDialog()
    }
}
exports.GtinForOtherDialog = GtinForOtherDialog;
//# sourceMappingURL=gtinForOtherDialog.js.map