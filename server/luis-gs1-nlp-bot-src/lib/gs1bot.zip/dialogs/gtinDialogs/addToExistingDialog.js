"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_1 = require("botbuilder");
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const prefixChoiceDialog_1 = require("./prefixChoiceDialog");
const TEXT_PROMPT = 'addToExistingPrefixTextPrompt';
const WATERFALL_DIALOG = 'addToExistingPrefixWaterfallDialog';
const PREFIX_CHOICE_DIALOG = 'addToExistingPrefixChoiceDialog;';
class AddToExistingPrefixDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'addToExistingDialog');
        this.addDialog(new botbuilder_dialogs_1.WaterfallDialog(WATERFALL_DIALOG, [
            // this.introStep.bind(this),
            this.askIfUserWantsToAddToExistingPrefixStep.bind(this),
            this.processResultStep.bind(this),
            this.returnResultStep.bind(this)
        ])).addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT))
            .addDialog(new prefixChoiceDialog_1.PrefixChoiceDialog(PREFIX_CHOICE_DIALOG));
        this.initialDialogId = WATERFALL_DIALOG;
    }
    askIfUserWantsToAddToExistingPrefixStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            const introActions = botbuilder_1.CardFactory.actions([strings_1.default.general.no, ...userDetails.validPrefixes]);
            return yield stepContext.prompt(TEXT_PROMPT, botbuilder_1.MessageFactory.suggestedActions(introActions, strings_1.default.gtin.add_to_existing));
        });
    }
    processResultStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const answerOfUser = stepContext.result;
            if (answerOfUser === strings_1.default.general.no) {
                return yield stepContext.beginDialog(PREFIX_CHOICE_DIALOG, { accessor: this.accessor });
            }
            else {
                yield stepContext.context.sendActivity(strings_1.default.gtin.chose_to_add_to_prefix(answerOfUser));
            }
            return yield stepContext.next(answerOfUser);
        });
    }
    returnResultStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            // tslint:disable-next-line: no-string-literal
            return yield stepContext.endDialog(stepContext.result);
        });
    }
}
exports.AddToExistingPrefixDialog = AddToExistingPrefixDialog;
//# sourceMappingURL=addToExistingDialog.js.map