import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class RetrieveRevenueDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private introStep;
    private readyStep;
    private checkRevenueStep;
    private processResultStep;
}
