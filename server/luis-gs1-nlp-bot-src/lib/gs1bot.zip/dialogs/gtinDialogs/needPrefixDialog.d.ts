import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class NeedPrefixDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private checkRevenueStep;
    private finalStep;
}
