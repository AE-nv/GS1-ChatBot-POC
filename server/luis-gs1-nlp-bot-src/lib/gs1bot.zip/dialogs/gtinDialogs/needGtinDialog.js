"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const PromptFactory_1 = require("../../util/PromptFactory");
const accountDialog_1 = require("../accountDialogs/accountDialog");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const addToExistingDialog_1 = require("./addToExistingDialog");
const prefixChoiceDialog_1 = require("./prefixChoiceDialog");
const ACCOUNT_DIALOG = 'accountDialog';
const PREFIX_TEXT_PROMPT = 'gtinExistingPrefixTextPrompt';
const PREFIX_CHOICE_DIALOG = 'gtinChoosePrefixDialog';
const ADD_TO_EXISTING_PREFIX_DIALOG = 'addToExistingPrefixDialog';
class NeedGtinDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'needGtinDialog');
        this.GTIN_WATERFALL_DIALOG = 'gtinWaterfallDialog';
        // this.graphD = new GraphDialog(PREFIX_CHOICE_DIALOG);
        this
            .addDialog(new botbuilder_dialogs_1.WaterfallDialog(this.GTIN_WATERFALL_DIALOG, [
            this.checkIfNewUserStep.bind(this),
            this.checkLoggedInStep.bind(this),
            this.checkValidPrefixStep.bind(this),
            this.processPrefixStep.bind(this),
            this.prefixDeterminesNrOfGtinsStep.bind(this),
            this.howMuchTradeUnitsStep.bind(this),
            this.processNrOfTradeUnitsStep.bind(this),
            this.processPrefixChoiceStep.bind(this),
            this.finalStep.bind(this)
        ]))
            .addDialog(new addToExistingDialog_1.AddToExistingPrefixDialog(ADD_TO_EXISTING_PREFIX_DIALOG))
            .addDialog(new prefixChoiceDialog_1.PrefixChoiceDialog(PREFIX_CHOICE_DIALOG))
            .addDialog(new accountDialog_1.AccountDialog(ACCOUNT_DIALOG))
            .addDialog(new botbuilder_dialogs_1.TextPrompt(PREFIX_TEXT_PROMPT));
        // this.connectGraph();
        this.initialDialogId = this.GTIN_WATERFALL_DIALOG;
    }
    // private connectGraph(){
    //     this.revenueKnownDialog.setFalseDialog(this.giveRevenueDialog);
    //     this.revenueKnownDialog.setTrueDialog(this.revenueCorrectDialog);
    // }
    checkIfNewUserStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            if (userDetails.newUser && userDetails.newUser === true) {
                yield stepContext.context.sendActivity(strings_1.default.main.new_user_documents);
            }
            // await stepContext.context.sendActivity(strings.account.need_to_be_logged_in);
            return yield stepContext.next();
        });
    }
    checkLoggedInStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            if (userDetails && (!userDetails.loggedIn || userDetails.loggedIn !== true)) {
                return yield stepContext.beginDialog(ACCOUNT_DIALOG, { accessor: this.accessor });
            }
            return yield stepContext.next();
        });
    }
    checkValidPrefixStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            if (!userDetails.validPrefixes || userDetails.validPrefixes.length === 0) {
                return yield stepContext.beginDialog(PREFIX_CHOICE_DIALOG, { accessor: this.accessor });
            }
            else {
                // HAS VALID PREFIX --> ASK TO ADD OR CREATE NEW
                return yield stepContext.beginDialog(ADD_TO_EXISTING_PREFIX_DIALOG, { accessor: this.accessor });
                // return await stepContext.cancelAllDialogs();
            }
        });
    }
    processPrefixStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            // tslint:disable-next-line: no-string-literal
            const answerOfUser = stepContext.result;
            const userDetails = yield this.getUserState(stepContext.context);
            // ADD TO EXISTING PREFIX?
            console.log(answerOfUser);
            if (answerOfUser === strings_1.default.general.no) {
                return yield stepContext.beginDialog(PREFIX_CHOICE_DIALOG, { accessor: this.accessor });
            }
            else if (userDetails.validPrefixes && userDetails.validPrefixes.find(prefix => prefix === answerOfUser)) {
                return yield stepContext.cancelAllDialogs();
            }
            else if (stepContext.result && stepContext.result.meta === 'userChoseSpecialOffer') {
                return yield stepContext.cancelAllDialogs();
            }
            return yield stepContext.next();
        });
    }
    prefixDeterminesNrOfGtinsStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            yield PromptFactory_1.getTextPrompt(stepContext, PREFIX_TEXT_PROMPT, strings_1.default.gtin.prefix_determines_gtins);
            return yield stepContext.next();
        });
    }
    howMuchTradeUnitsStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield PromptFactory_1.getTextPrompt(stepContext, PREFIX_TEXT_PROMPT, strings_1.default.gtin.how_many_trade_units);
        });
    }
    processNrOfTradeUnitsStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const nrOfUnits = stepContext.result;
            const userDetails = yield this.getUserState(stepContext.context);
            const suggestedPrefixes = this.calcPrefix(nrOfUnits, Number.parseInt(userDetails.revenue));
            userDetails.suggestedPrefixes = suggestedPrefixes;
            console.log(suggestedPrefixes);
            return yield PromptFactory_1.getChoicePrompt(stepContext, PREFIX_TEXT_PROMPT, strings_1.default.gtin.recommend_these_prefixes(suggestedPrefixes), suggestedPrefixes.map(s => s.Prefix1));
        });
    }
    processPrefixChoiceStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            const answerOfUser = stepContext.result;
            const selectedPrefix = userDetails.suggestedPrefixes && userDetails.suggestedPrefixes.find(s => s.Prefix1 === answerOfUser);
            let link = '';
            console.log(answerOfUser);
            console.log(userDetails.suggestedPrefixes);
            if (selectedPrefix) {
                link = selectedPrefix.L1;
            }
            console.log(answerOfUser);
            yield PromptFactory_1.getTextPrompt(stepContext, PREFIX_TEXT_PROMPT, strings_1.default.gtin.u_chose_prefix_x(answerOfUser, link));
            return yield stepContext.next();
        });
    }
    finalStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield stepContext.endDialog();
        });
    }
    calcPrefix(units, revenue) {
        if (units < 11) {
            if (revenue < 50) {
                return [
                    { Prefix1: 'lengte 11', Aantal1: 10, YearlyF1: 55, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/CF0BB86C-90CB-E811-A839-000D3AB48443' },
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 125, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' }
                ];
            }
            if (revenue < 250) {
                return [
                    { Prefix1: 'lengte 11', Aantal1: 10, YearlyF1: 55, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/CF0BB86C-90CB-E811-A839-000D3AB48443' },
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 189, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' }
                ];
            }
            if (revenue < 1000) {
                return [
                    { Prefix1: 'lengte 11', Aantal1: 10, YearlyF1: 55, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/CF0BB86C-90CB-E811-A839-000D3AB48443' },
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 220, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' }
                ];
            }
            if (revenue < 2500) {
                return [
                    { Prefix1: 'lengte 11', Aantal1: 10, YearlyF1: 55, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/CF0BB86C-90CB-E811-A839-000D3AB48443' },
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 246, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' }
                ];
            }
            if (revenue < 6000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 476, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 476, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 12000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 798, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 798, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 25000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 983, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 983, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 125000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 1433, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 1433, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 500000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 2047, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 2047, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            return [
                { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 2559, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 2559, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
            ];
        }
        if (units < 101) {
            if (revenue < 50) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 125, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 125, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 250) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 189, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 189, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 1000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 220, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 220, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 2500) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 246, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 246, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 6000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 476, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 476, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 12000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 798, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 798, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 25000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 983, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 983, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 125000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 1433, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 1433, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 500000) {
                return [
                    { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 2047, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 2047, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
                ];
            }
            return [
                { Prefix1: 'lengte 10', Aantal1: 100, YearlyF1: 2559, JoiningF1: 0, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/5FF09961-DD77-E511-9400-0050568F2F51' },
                { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 2559, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' }
            ];
        }
        if (units < 1001) {
            if (revenue < 50) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 125, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 125, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 250) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 189, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 189, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 1000) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 220, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 220, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 2500) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 246, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 246, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 6000) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 476, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 476, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 12000) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 798, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 798, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 25000) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 983, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 983, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 125000) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 1433, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 1433, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 500000) {
                return [
                    { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 2047, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 2047, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
                ];
            }
            return [
                { Prefix1: 'lengte 9', Aantal1: 1.000, YearlyF1: 2559, JoiningF1: 600, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/2B36BFA3-451B-E511-93FB-0050568F2F51' },
                { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 2559, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' }
            ];
        }
        if (units < 10001) {
            if (revenue < 50) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 125, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 125, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 250) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 189, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 189, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 1000) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 220, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 220, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 2500) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 246, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 246, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 6000) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 476, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 476, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 12000) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 798, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 798, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 25000) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 983, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 983, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 125000) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 1433, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 1433, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 500000) {
                return [
                    { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 2047, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 2047, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            return [
                { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 2559, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/BC73BF80-451B-E511-93FB-0050568F2F51' },
                { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 2559, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
            ];
        }
        if (units < 100001) {
            if (revenue < 50) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 125, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 250) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 189, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 1000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 220, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 2500) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 246, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 6000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 476, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 12000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 798, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 25000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 983, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 125000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 1433, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 500000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 2047, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            return [
                { Prefix1: 'lengte 8', Aantal1: 10.000, YearlyF1: 2559, JoiningF1: 1.000, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
            ];
        }
        if (units > 100000) {
            if (revenue < 50) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 125, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 250) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 189, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 1000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 220, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 2500) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 246, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 6000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 476, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 12000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 798, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 25000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 983, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 125000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 1433, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            if (revenue < 500000) {
                return [
                    { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 2047, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
                ];
            }
            return [
                { Prefix1: 'lengte 7', Aantal1: 100.000, YearlyF1: 2559, JoiningF1: 1250, L1: 'HTTPS://WWW.GS1BELU.ORG/NL/EXTRANET/ACCOUNT/PRODUCTS/ORDER/PRODUCT/4EEF2163-451B-E511-93FB-0050568F2F51' }
            ];
        }
    }
}
exports.NeedGtinDialog = NeedGtinDialog;
//# sourceMappingURL=needGtinDialog.js.map