"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const PromptFactory_1 = require("../../util/PromptFactory");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const gtinForCDDialog_1 = require("./gtinForCDDialog");
const retrieveRevenueDialog_1 = require("./retrieveRevenueDialog");
const TEXT_PROMPT = 'prefixChoiceTextPrompt';
const CHOICE_PROMPT = 'prefixChoiceChoicePrompt';
const WATERFALL_DIALOG = 'prefixChoiceWaterfallDialog';
// const GTIN_FOR_OTHER = 'gtinForCDOtherDialog';
const GTIN_FOR_CD_DVD_VINYL = 'gtinForCDCDDVDVinyl';
const RETRIEVE_REVENUE_DIALOG = 'retrieveRevenueDialog';
class PrefixChoiceDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'prefixChoiceDialog');
        this
            .addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT))
            .addDialog(new botbuilder_dialogs_1.WaterfallDialog(WATERFALL_DIALOG, [
            this.introToGtinForCDStep.bind(this),
            this.needGtinForCDorOtherStep.bind(this),
            this.pickNextDialogStep.bind(this),
            this.finalMainStep.bind(this)
        ]))
            .addDialog(new gtinForCDDialog_1.GtinForCDDialog(GTIN_FOR_CD_DVD_VINYL))
            .addDialog(new retrieveRevenueDialog_1.RetrieveRevenueDialog(RETRIEVE_REVENUE_DIALOG));
        // .addDialog(new GtinForOtherDialog(GTIN_FOR_OTHER));
        this.initialDialogId = WATERFALL_DIALOG;
    }
    introToGtinForCDStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            yield PromptFactory_1.getTextPrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.intro_to_cd_etc);
            return yield stepContext.next();
        });
    }
    needGtinForCDorOtherStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield PromptFactory_1.getChoicePrompt(stepContext, TEXT_PROMPT, strings_1.default.gtin.for_cd_or_other, [strings_1.default.gtin.possible_answers.other, strings_1.default.gtin.possible_answers.cd_dvd_vinyl]);
        });
    }
    pickNextDialogStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const answerOfUser = stepContext.result;
            switch (answerOfUser) {
                case strings_1.default.gtin.possible_answers.other:
                    // await getTextPrompt(stepContext,TEXT_PROMPT,strings.gtin.ask_some_questions);
                    return yield stepContext.beginDialog(RETRIEVE_REVENUE_DIALOG, { accessor: this.accessor, firstTimeEnter: true });
                case strings_1.default.gtin.possible_answers.cd_dvd_vinyl:
                    return yield stepContext.beginDialog(GTIN_FOR_CD_DVD_VINYL, { accessor: this.accessor });
            }
            return yield stepContext.next();
        });
    }
    finalMainStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield stepContext.endDialog(stepContext.result);
            // stepContext.cancelAllDialogs();
        });
    }
}
exports.PrefixChoiceDialog = PrefixChoiceDialog;
//# sourceMappingURL=prefixChoiceDialog.js.map