import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class PrefixChoiceDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private needGtinForCDorOtherStep;
    private pickNextDialogStep;
    private finalMainStep;
}
