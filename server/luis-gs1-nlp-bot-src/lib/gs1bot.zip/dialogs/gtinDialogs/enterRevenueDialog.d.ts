import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class EnterRevenueDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private giveRevenueStep;
    private finalStep;
}
