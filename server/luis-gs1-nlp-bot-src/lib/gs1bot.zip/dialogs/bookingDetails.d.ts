export interface BookingDetails {
    destination?: string;
    origin?: string;
    travelDate?: string;
}
