import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class CreateAccountDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private referToAccountCreationPageStep;
    private accountCreatedStep;
}
