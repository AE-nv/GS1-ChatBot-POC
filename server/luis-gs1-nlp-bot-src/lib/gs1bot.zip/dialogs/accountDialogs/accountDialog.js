"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_1 = require("botbuilder");
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const createAccountDialog_1 = require("./createAccountDialog");
const loginDialog_1 = require("./loginDialog");
const TEXT_PROMPT = 'accountTextPrompt';
const WATERFALL_DIALOG = 'accountWaterfallDialog';
const LOGIN_DIALOG = 'accountLoginDialog';
const CREATE_ACCOUNT_DIALOG = 'createAccountDialog';
class AccountDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'accountDialog');
        this
            .addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT))
            .addDialog(new loginDialog_1.LoginDialog(LOGIN_DIALOG))
            .addDialog(new createAccountDialog_1.CreateAccountDialog(CREATE_ACCOUNT_DIALOG))
            .addDialog(new botbuilder_dialogs_1.WaterfallDialog(WATERFALL_DIALOG, [
            this.askLoginOrCreateStep.bind(this),
            this.loginOrCreateStep.bind(this)
        ]));
        this.initialDialogId = WATERFALL_DIALOG;
    }
    askLoginOrCreateStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            //TODO
            if (!!userDetails.newUser) {
                console.log('accountDialog: asked login or create');
                // THE USER IS A NEW USER --> CREATE ACCOUNT YES OR NO, or LOGIN IF MISTAKE
                const introActions = botbuilder_1.CardFactory.actions([strings_1.default.account.create_account, strings_1.default.account.log_me_in]);
                return yield stepContext.prompt(TEXT_PROMPT, botbuilder_1.MessageFactory.suggestedActions(introActions, strings_1.default.account.saw_new_user_create_account));
            }
            else {
                console.log('accountDialog: existing user ask login');
                // THE USER IS AN EXISTING USER --> start login dialog
                return yield stepContext.beginDialog(LOGIN_DIALOG, { accessor: this.accessor });
            }
        });
    }
    loginOrCreateStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const answerOfUser = stepContext.result;
            console.log(`accountDialog: login or create step: ${answerOfUser}`);
            switch (answerOfUser) {
                case strings_1.default.account.log_me_in:
                    return yield stepContext.beginDialog(LOGIN_DIALOG, { accessor: this.accessor });
                case strings_1.default.account.create_account:
                    return yield stepContext.beginDialog(CREATE_ACCOUNT_DIALOG, { accessor: this.accessor });
            }
            return yield stepContext.endDialog(stepContext.options);
        });
    }
}
exports.AccountDialog = AccountDialog;
//# sourceMappingURL=accountDialog.js.map