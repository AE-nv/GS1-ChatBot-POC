"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_1 = require("botbuilder");
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
const cancelAndHelpDialog_1 = require("../cancelAndHelpDialog");
const strings_1 = __importDefault(require("../strings"));
const TEXT_PROMPT = 'loginTextPrompt';
const WATERFALL_DIALOG = 'loginWaterfallDialog';
class LoginDialog extends cancelAndHelpDialog_1.CancelAndHelpDialog {
    constructor(id) {
        super(id || 'loginDialog');
        this
            .addDialog(new botbuilder_dialogs_1.TextPrompt(TEXT_PROMPT))
            .addDialog(new botbuilder_dialogs_1.WaterfallDialog(WATERFALL_DIALOG, [
            this.askIfWantToLoginStep.bind(this),
            this.processAnswerStep.bind(this)
        ]));
        this.initialDialogId = WATERFALL_DIALOG;
    }
    askIfWantToLoginStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const introActions = botbuilder_1.CardFactory.actions([strings_1.default.account.i_logged_in]);
            return yield stepContext.prompt(TEXT_PROMPT, botbuilder_1.MessageFactory.suggestedActions(introActions, strings_1.default.account.not_logged_in_yet));
        });
    }
    processAnswerStep(stepContext) {
        return __awaiter(this, void 0, void 0, function* () {
            const userDetails = yield this.getUserState(stepContext.context);
            userDetails.loggedIn = true;
            return yield stepContext.endDialog(stepContext.options);
        });
    }
}
exports.LoginDialog = LoginDialog;
//# sourceMappingURL=loginDialog.js.map