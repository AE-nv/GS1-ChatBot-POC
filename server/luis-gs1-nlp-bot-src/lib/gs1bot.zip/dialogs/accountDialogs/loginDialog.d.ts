import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class LoginDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private askIfWantToLoginStep;
    private processAnswerStep;
}
