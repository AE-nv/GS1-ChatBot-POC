import { CancelAndHelpDialog } from '../cancelAndHelpDialog';
export declare class AccountDialog extends CancelAndHelpDialog {
    constructor(id: any);
    private askLoginOrCreateStep;
    private loginOrCreateStep;
}
