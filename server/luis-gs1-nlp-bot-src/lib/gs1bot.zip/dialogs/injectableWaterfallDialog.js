"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_dialogs_1 = require("botbuilder-dialogs");
class InjectableWaterfallDialog extends botbuilder_dialogs_1.WaterfallDialog {
    injectStepAtIndex(step, index) {
        this.steps.splice(index, 0, step);
    }
    injectStepBeforeLast(step) {
        this.injectStepAtIndex(step, this.steps.length - 1);
    }
}
exports.InjectableWaterfallDialog = InjectableWaterfallDialog;
//# sourceMappingURL=injectableWaterfallDialog.js.map