export declare class ComplexDialog {
    dialogText: string;
    private options;
    private DEFAULT_NEXT_KEY;
    private dialogTurnResult;
    constructor(dialogText: string, options?: {
        [answers: string]: ComplexDialog;
    });
    getNext(answer?: string): ComplexDialog;
    readonly getPossibleAnswers: string[];
    addOption(answer: string | undefined, dialog: ComplexDialog): ComplexDialog;
}
export declare const prefixChoiceDialog: ComplexDialog;
