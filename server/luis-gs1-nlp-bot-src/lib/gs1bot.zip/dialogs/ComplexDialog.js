"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ComplexDialog {
    constructor(dialogText, options) {
        this.dialogText = dialogText;
        this.options = options;
    }
    getNext(answer) {
        return this.options[answer] ? this.options[answer] : null;
    }
}
exports.ComplexDialog = ComplexDialog;
//# sourceMappingURL=ComplexDialog.js.map