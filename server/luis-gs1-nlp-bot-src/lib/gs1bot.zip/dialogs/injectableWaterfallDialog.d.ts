import { WaterfallDialog, WaterfallStep } from 'botbuilder-dialogs';
export declare class InjectableWaterfallDialog extends WaterfallDialog {
    injectStepAtIndex(step: WaterfallStep, index: number): void;
    injectStepBeforeLast(step: WaterfallStep): void;
}
