"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var GS1DialogStateMembers;
(function (GS1DialogStateMembers) {
    GS1DialogStateMembers["newUser"] = "newUser";
    GS1DialogStateMembers["loggedIn"] = "loggedIn";
    GS1DialogStateMembers["validPrefixes"] = "validPrefixes";
})(GS1DialogStateMembers = exports.GS1DialogStateMembers || (exports.GS1DialogStateMembers = {}));
//# sourceMappingURL=userDetails.js.map