import { Dialog, DialogTurnResult } from 'botbuilder-dialogs';
export declare class DynamicWaterfall {
    private currentStep;
    private nextDynamicWaterfall;
    getNext(): DynamicWaterfall;
    /**
     * Sets the step of this DynamicWaterfall, constructs a new one, and sets this new one as the next of this dynamic waterfall.
     * then returns the new dynamic waterfall.
     * @param step
     */
    addStep(step: (usedDialog: Dialog) => Promise<DialogTurnResult>): DynamicWaterfall;
}
export declare const testWaterfall: DynamicWaterfall;
