"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class DynamicWaterfall {
    // public getStep(stepContext: WaterfallStepContext): Promise<DialogTurnResult> {
    //     // return this.currentStep(stepContext);
    // }
    getNext() {
        return this.nextDynamicWaterfall;
    }
    /**
     * Sets the step of this DynamicWaterfall, constructs a new one, and sets this new one as the next of this dynamic waterfall.
     * then returns the new dynamic waterfall.
     * @param step
     */
    addStep(step) {
        this.currentStep = step;
        const newWaterfall = new DynamicWaterfall();
        this.nextDynamicWaterfall = newWaterfall;
        return newWaterfall;
    }
}
exports.DynamicWaterfall = DynamicWaterfall;
exports.testWaterfall = new DynamicWaterfall();
//# sourceMappingURL=DynamicWaterfall.js.map