import { DialogContext, DialogTurnResult, WaterfallStepContext } from 'botbuilder-dialogs';
export declare function getChoicePrompt(stepContext: DialogContext, textPromptId: string, displayText: string, options: string[]): Promise<DialogTurnResult<any>>;
export declare function getTextPrompt(stepContext: DialogContext, textPromptId: string, displayText: string): Promise<DialogTurnResult<any>>;
export declare function getChoiceStep(textPromptId: string, displayText: string, options: string[]): (stepContext: DialogContext) => Promise<DialogTurnResult>;
export declare function getTextStep(textPromptId: string, displayTest: string): (stepContext: WaterfallStepContext<{}>) => Promise<DialogTurnResult<any>>;
