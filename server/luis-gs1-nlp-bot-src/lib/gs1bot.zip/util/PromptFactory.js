"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_1 = require("botbuilder");
function getChoicePrompt(stepContext, textPromptId, displayText, options) {
    const introActions = botbuilder_1.CardFactory.actions(options);
    return stepContext.prompt(textPromptId, botbuilder_1.MessageFactory.suggestedActions(introActions, displayText));
}
exports.getChoicePrompt = getChoicePrompt;
function getTextPrompt(stepContext, textPromptId, displayText) {
    return stepContext.prompt(textPromptId, displayText);
}
exports.getTextPrompt = getTextPrompt;
function getChoiceStep(textPromptId, displayText, options) {
    return (stepContext) => getChoicePrompt(stepContext, textPromptId, displayText, options);
}
exports.getChoiceStep = getChoiceStep;
function getTextStep(textPromptId, displayTest) {
    return (stepContext) => { getTextPrompt(stepContext, textPromptId, displayTest); return stepContext.next(); };
}
exports.getTextStep = getTextStep;
//# sourceMappingURL=PromptFactory.js.map