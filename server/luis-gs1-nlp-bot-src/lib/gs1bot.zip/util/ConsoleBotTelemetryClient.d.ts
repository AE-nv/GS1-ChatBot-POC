import { NullTelemetryClient, TelemetryEvent } from 'botbuilder';
export declare class ConsoleLogTelemetryClient extends NullTelemetryClient {
    trackEvent(telemetryEvent: TelemetryEvent): void;
}
