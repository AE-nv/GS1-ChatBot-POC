"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const botbuilder_1 = require("botbuilder");
class ConsoleLogTelemetryClient extends botbuilder_1.NullTelemetryClient {
    trackEvent(telemetryEvent) {
        const dID = telemetryEvent.properties.DialogId;
        const stepName = telemetryEvent.properties.StepName || '??';
        console.log(`${telemetryEvent.name} --> id: ${dID} --> step: ${stepName}`);
        // console.log('-----------------------------------------------------------------------');
        // console.log(`tm:  ${telemetryEvent.name} :: ${telemetryEvent.properties.DialogId}`);
    }
}
exports.ConsoleLogTelemetryClient = ConsoleLogTelemetryClient;
//# sourceMappingURL=ConsoleBotTelemetryClient.js.map